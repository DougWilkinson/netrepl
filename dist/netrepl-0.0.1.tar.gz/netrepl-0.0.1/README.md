network based repl tool for:

- copying files (compile to .mpy option)
- viewing repl output (if code is printing data)
- backup files to local directory

uses md5 hash to determine if copy is needed

